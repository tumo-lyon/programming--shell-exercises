export const inferLabel = () => {};
