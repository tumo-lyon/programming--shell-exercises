const randomId = (): string => Math.random().toString(16).slice(2);

export default randomId;
