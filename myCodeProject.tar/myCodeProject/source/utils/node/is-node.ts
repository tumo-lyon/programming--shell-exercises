// eslint-disable-next-line n/prefer-global/process
export default Boolean(process?.versions?.node);
